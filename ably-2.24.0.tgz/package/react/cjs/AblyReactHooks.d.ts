import * as Ably from 'ably';
export type ChannelNameAndOptions = {
    /**
     * The name of the channel to use. When omitted, channel hooks resolve to the
     * channel named by the closest enclosing `ChannelProvider`. Resolution is
     * scoped by `ablyId`, so a channel is only inferred from a `ChannelProvider`
     * that uses the same `ablyId` (the `default` one when none is provided).
     */
    channelName?: string;
    ablyId?: string;
    skip?: boolean;
    onConnectionError?: (error: Ably.ErrorInfo) => unknown;
    onChannelError?: (error: Ably.ErrorInfo) => unknown;
};
export type ChannelNameAndAblyId = Pick<ChannelNameAndOptions, 'channelName' | 'ablyId'>;
export type ChannelParameters = string | ChannelNameAndOptions;
export declare const version = "2.24.0";
/**
 * channel options for react-hooks
 */
export declare function channelOptionsForReactHooks(options?: Ably.ChannelOptions): Ably.ChannelOptions;
