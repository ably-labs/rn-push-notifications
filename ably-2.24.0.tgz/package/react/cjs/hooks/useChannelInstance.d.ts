import { ChannelContextProps } from '../AblyContext.js';
export type ResolvedChannelContextProps = ChannelContextProps & {
    channelName: string;
};
export declare function useChannelInstance(ablyId?: string, channelName?: string): ResolvedChannelContextProps;
