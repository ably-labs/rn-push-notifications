import type * as Ably from 'ably';
import { ChannelParameters } from '../AblyReactHooks.js';
export interface PresenceResult<T> {
    updateStatus: (messageOrPresenceObject: T) => Promise<void>;
    connectionError: Ably.ErrorInfo | null;
    channelError: Ably.ErrorInfo | null;
}
/**
 * Enter the presence set of a channel.
 *
 * The channel name can be omitted to use the channel from the nearest `ChannelProvider`.
 * Because the presence data can itself be a string or object, it is indistinguishable
 * from a channel name or options object, so it cannot be passed as the first argument.
 * To infer the channel while still providing presence data, pass `undefined` as the
 * first argument: `usePresence(undefined, presenceData)`.
 */
export declare function usePresence<T = any>(channelNameOrNameAndOptions?: ChannelParameters, messageOrPresenceObject?: T): PresenceResult<T>;
