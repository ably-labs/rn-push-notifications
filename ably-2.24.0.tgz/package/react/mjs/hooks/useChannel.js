import { useEffect, useMemo, useRef } from 'react';
import { useAbly } from './useAbly.js';
import { useStateErrors } from './useStateErrors.js';
import { useChannelInstance } from './useChannelInstance.js';
import { useChannelAttach } from './useChannelAttach.js';
export function useChannel(channelNameOrNameAndOptionsOrCallback, eventOrCallback, callback) {
    // The first argument is the message callback when the channel name is
    // inferred from a surrounding ChannelProvider, e.g. useChannel(listener).
    const inferChannelFromNearestProvider = typeof channelNameOrNameAndOptionsOrCallback === 'function';
    const channelNameOrNameAndOptions = inferChannelFromNearestProvider
        ? undefined
        : channelNameOrNameAndOptionsOrCallback;
    const eventOrCallbackArg = inferChannelFromNearestProvider
        ? channelNameOrNameAndOptionsOrCallback
        : eventOrCallback;
    const channelHookOptions = typeof channelNameOrNameAndOptions === 'object'
        ? channelNameOrNameAndOptions
        : channelNameOrNameAndOptions === undefined
            ? {}
            : { channelName: channelNameOrNameAndOptions };
    const ably = useAbly(channelHookOptions.ablyId);
    const { skip } = channelHookOptions;
    const { channel, derived, channelName } = useChannelInstance(channelHookOptions.ablyId, channelHookOptions.channelName);
    const publish = useMemo(() => {
        if (!derived)
            return channel.publish.bind(channel);
        const regularChannel = ably.channels.get(channelName);
        // For derived channels we use transient publish (it won't attach to the channel)
        return regularChannel.publish.bind(regularChannel);
    }, [ably.channels, derived, channel, channelName]);
    const channelEvent = typeof eventOrCallbackArg === 'string' ? eventOrCallbackArg : null;
    const ablyMessageCallback = typeof eventOrCallbackArg === 'string' ? callback : eventOrCallbackArg;
    const ablyMessageCallbackRef = useRef(ablyMessageCallback);
    const history = useMemo(() => ((params) => channel.history(params)), [channel]);
    const { connectionError, channelError } = useStateErrors(channelHookOptions);
    useEffect(() => {
        ablyMessageCallbackRef.current = ablyMessageCallback;
    }, [ablyMessageCallback]);
    useEffect(() => {
        const listener = ablyMessageCallbackRef.current
            ? (message) => {
                ablyMessageCallbackRef.current && ablyMessageCallbackRef.current(message);
            }
            : null;
        const subscribeArgs = listener
            ? channelEvent === null
                ? [listener]
                : [channelEvent, listener]
            : null;
        if (!skip && subscribeArgs) {
            handleChannelMount(channel, ...subscribeArgs);
        }
        return () => {
            !skip && subscribeArgs && handleChannelUnmount(channel, ...subscribeArgs);
        };
    }, [channelEvent, channel, skip]);
    useChannelAttach(channel, channelHookOptions.ablyId, skip);
    return { channel, publish, history, ably, connectionError, channelError };
}
async function handleChannelMount(channel, ...subscribeArgs) {
    await channel.subscribe(...subscribeArgs);
}
async function handleChannelUnmount(channel, ...subscribeArgs) {
    await channel.unsubscribe(...subscribeArgs);
}
//# sourceMappingURL=useChannel.js.map