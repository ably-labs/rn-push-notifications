import { useEventListener } from './useEventListener.js';
import { useChannelInstance } from './useChannelInstance.js';
export function useChannelStateListener(channelNameOrNameAndAblyIdOrListener, stateOrListener, listener) {
    // The first argument is the listener when the channel name is inferred from a
    // surrounding ChannelProvider, e.g. useChannelStateListener(listener).
    const inferChannelFromNearestProvider = typeof channelNameOrNameAndAblyIdOrListener === 'function';
    const channelNameOrNameAndAblyId = inferChannelFromNearestProvider
        ? undefined
        : channelNameOrNameAndAblyIdOrListener;
    const stateOrListenerArg = inferChannelFromNearestProvider
        ? channelNameOrNameAndAblyIdOrListener
        : stateOrListener;
    const channelHookOptions = typeof channelNameOrNameAndAblyId === 'object'
        ? channelNameOrNameAndAblyId
        : channelNameOrNameAndAblyId === undefined
            ? {}
            : { channelName: channelNameOrNameAndAblyId };
    const { ablyId, channelName } = channelHookOptions;
    const { channel } = useChannelInstance(ablyId, channelName);
    const _listener = typeof listener === 'function'
        ? listener
        : typeof stateOrListenerArg === 'function'
            ? stateOrListenerArg
            : undefined;
    const state = typeof stateOrListenerArg === 'function' ? undefined : stateOrListenerArg;
    useEventListener(channel, _listener, state);
}
//# sourceMappingURL=useChannelStateListener.js.map